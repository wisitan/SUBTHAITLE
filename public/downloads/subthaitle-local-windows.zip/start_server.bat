@echo off
title SUBTHAITLE - Local Whisper Server
cd /d "%~dp0"

echo =======================================================
echo   🪟 SUBTHAITLE Local Server Launcher (Windows)
echo =======================================================

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo   ❌ ไม่พบ Python ในเครื่อง กรุณาดาวน์โหลดและติดตั้งจาก python.org
    echo      (อย่าลืมติ๊กเลือก "Add Python to PATH" ตอนติดตั้งด้วยนะครับ)
    pause
    exit /b 1
)

if not exist ".venv" (
    echo   📦 กำลังสร้างสภาพแวดล้อม Python (.venv)...
    python -m venv .venv
    echo   ⬇️ กำลังติดตั้งไลบรารีที่จำเป็น (ทำครั้งแรกครั้งเดียว)...
    call .venv\Scripts\activate.bat
    python -m pip install --upgrade pip
    python -m pip install -r requirements-win.txt
) else (
    call .venv\Scripts\activate.bat
)

echo   🚀 กำลังเริ่มต้น Local Whisper Server บน http://localhost:8765 ...
echo   💡 เปิดเว็บ SUBTHAITLE แล้วใช้งานได้ทันที (ปิดหน้านี้เมื่อเลิกใช้)
echo =======================================================
echo.

python server.py
pause
