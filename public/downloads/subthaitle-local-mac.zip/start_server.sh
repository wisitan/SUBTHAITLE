#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

echo "======================================================="
echo "  🍎 SUBTHAITLE Local Server Launcher (Mac)"
echo "======================================================="

# Check Apple Silicon vs Intel
ARCH="$(uname -m)"
if [[ "$ARCH" == "arm64" ]]; then
  echo "  ✅ Apple Silicon detected (M1/M2/M3/M4)"
  REQ_FILE="requirements-mac.txt"
else
  echo "  ⚠️ Intel Mac detected (Using faster-whisper)"
  REQ_FILE="requirements-win.txt"
fi

# Find Python 3
PYTHON_BIN=""
if command -v python3 >/dev/null 2>&1; then
  PYTHON_BIN="python3"
elif [ -x "/opt/homebrew/bin/python3" ]; then
  PYTHON_BIN="/opt/homebrew/bin/python3"
elif [ -x "/usr/local/bin/python3" ]; then
  PYTHON_BIN="/usr/local/bin/python3"
fi

if [[ -z "$PYTHON_BIN" ]]; then
  echo "  ❌ ไม่พบ Python 3 ในเครื่อง กรุณาติดตั้งผ่าน Homebrew หรือ python.org"
  exit 1
fi

VENV_DIR="$DIR/.venv"

# Create Virtual Environment if not exists
if [[ ! -d "$VENV_DIR" ]]; then
  echo "  📦 กำลังสร้างสภาพแวดล้อม Python (.venv)..."
  "$PYTHON_BIN" -m venv "$VENV_DIR"
  echo "  ⬇️ กำลังติดตั้งไลบรารีที่จำเป็น (ทำครั้งแรกครั้งเดียว)..."
  "$VENV_DIR/bin/python" -m pip install --upgrade pip
  "$VENV_DIR/bin/python" -m pip install -r "$REQ_FILE"
fi

# Start Server
echo "  🚀 กำลังเริ่มต้น Local Whisper Server บน http://localhost:8765 ..."
echo "  💡 เปิดเว็บ SUBTHAITLE แล้วใช้งานได้ทันที (ปิดหน้านี้เมื่อเลิกใช้)"
echo "======================================================="
echo ""

exec "$VENV_DIR/bin/python" server.py
