# 🚀 SUBTHAITLE Local Whisper Server

เซิร์ฟเวอร์ถอดเสียงภาษาไทยออฟไลน์สำหรับแอป **SUBTHAITLE** ทำงานบนเครื่องของคุณเอง 100% ข้อมูลปลอดภัยไม่ส่งออกนอกเครื่อง และถอดเสียงได้ไม่จำกัดความยาว

---

## 🍎 วิธีเปิดใช้งานสำหรับ Mac (Apple Silicon M1/M2/M3/M4)

1. ดับเบิลคลิกไฟล์ **`start_server.command`** (หรือรัน `./start_server.sh` ใน Terminal)
2. ระบบจะติดตั้งและสตาร์ตเซิร์ฟเวอร์ให้อัตโนมัติที่ `http://localhost:8765`
3. เปิดหน้าเว็บ [SUBTHAITLE](https://subthaitle.vercel.app) และเลือกโหมด **Local Whisper (Mac)** เพื่อเริ่มใช้งานได้ทันที

---

## 🪟 วิธีเปิดใช้งานสำหรับ Windows (PC / NVIDIA GPU)

1. ดับเบิลคลิกไฟล์ **`start_server.bat`**
2. ระบบจะติดตั้งและสตาร์ตเซิร์ฟเวอร์ให้อัตโนมัติที่ `http://localhost:8765`
3. เปิดหน้าเว็บ [SUBTHAITLE](https://subthaitle.vercel.app) และเลือกโหมด **Local Whisper** เพื่อเริ่มใช้งานได้ทันที
