#!/usr/bin/env python3
"""
SUBTHAITLE - Local Whisper API Server
Cross-platform local transcription server for Mac (Apple Silicon) and Windows (NVIDIA/CPU)
"""

import os
import sys
import tempfile
import platform
import shutil
from pathlib import Path
from typing import Optional, List

from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(
    title="SUBTHAITLE Local Whisper Server",
    description="Offline Thai AI Transcription Server with Word-level Timestamps",
    version="1.0.0",
)

# Enable CORS for Web App (Localhost, Vercel preview, and production domains)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Detect runtime environment & platform
IS_APPLE_SILICON = platform.system() == "Darwin" and platform.machine() == "arm64"
PLATFORM_SYSTEM = platform.system()

# Check available engines
ENGINE = "none"
try:
    if IS_APPLE_SILICON:
        import mlx_whisper
        ENGINE = "mlx-whisper"
except ImportError:
    pass

if ENGINE == "none":
    try:
        from faster_whisper import WhisperModel
        ENGINE = "faster-whisper"
    except ImportError:
        pass

if ENGINE == "none":
    try:
        import whisper
        ENGINE = "openai-whisper"
    except ImportError:
        pass

# Cached model instance for faster-whisper / openai-whisper
_cached_faster_model = None


class WordItem(BaseModel):
    word: str
    start: float
    end: float
    confidence: Optional[float] = 1.0


class SegmentItem(BaseModel):
    id: int
    start: float
    end: float
    text: str


class TranscribeResponse(BaseModel):
    success: bool
    text: str
    segments: List[SegmentItem]
    words: List[WordItem]
    duration: Optional[float] = None
    engine: str
    model: str


@app.get("/health")
async def health_check():
    return {
        "status": "ok",
        "engine": ENGINE,
        "platform": f"{PLATFORM_SYSTEM} ({platform.machine()})",
        "is_apple_silicon": IS_APPLE_SILICON,
        "default_model": "whisper-large-v3",
        "message": "SUBTHAITLE Local Whisper Server is online and ready!",
    }


def transcribe_with_mlx(
    audio_path: str,
    model_name: str = "mlx-community/whisper-large-v3",
    language: str = "th",
    initial_prompt: str = "ตัดคำภาษาไทย เว้นวรรคตามหลักภาษาอย่างเป็นธรรมชาติ ซับไตเติลภาษาไทย",
) -> dict:
    import mlx_whisper

    result = mlx_whisper.transcribe(
        audio_path,
        path_or_hf_repo=model_name,
        language=language,
        word_timestamps=True,
        condition_on_previous_text=False,
        initial_prompt=initial_prompt,
        temperature=0.0,
    )
    return result


def transcribe_with_faster_whisper(
    audio_path: str,
    model_name: str = "large-v3",
    language: str = "th",
    initial_prompt: str = "ตัดคำภาษาไทย เว้นวรรคตามหลักภาษาอย่างเป็นธรรมชาติ ซับไตเติลภาษาไทย",
) -> dict:
    global _cached_faster_model
    from faster_whisper import WhisperModel

    # Determine device: CUDA if available, otherwise CPU with int8 quantization
    device = "cuda" if os.environ.get("USE_CUDA", "1") == "1" and shutil.which("nvidia-smi") else "cpu"
    compute_type = "float16" if device == "cuda" else "int8"

    if _cached_faster_model is None:
        print(f"[SUBTHAITLE] Loading faster-whisper model '{model_name}' on {device} ({compute_type})...")
        _cached_faster_model = WhisperModel(model_name, device=device, compute_type=compute_type)

    segments_gen, info = _cached_faster_model.transcribe(
        audio_path,
        language=language,
        initial_prompt=initial_prompt,
        word_timestamps=True,
        temperature=0.0,
        condition_on_previous_text=False,
    )

    segments = []
    all_words = []
    full_text = []

    for seg_idx, segment in enumerate(segments_gen):
        seg_text = segment.text.strip()
        full_text.append(seg_text)
        seg_words = []

        if segment.words:
            for w in segment.words:
                w_item = {
                    "word": w.word.strip(),
                    "start": round(w.start, 3),
                    "end": round(w.end, 3),
                    "confidence": round(w.probability, 2) if hasattr(w, "probability") else 1.0,
                }
                seg_words.append(w_item)
                all_words.append(w_item)

        segments.append({
            "id": seg_idx,
            "start": round(segment.start, 3),
            "end": round(segment.end, 3),
            "text": seg_text,
            "words": seg_words,
        })

    return {
        "text": " ".join(full_text),
        "segments": segments,
        "words": all_words,
        "duration": info.duration if hasattr(info, "duration") else None,
    }


@app.post("/transcribe", response_model=TranscribeResponse)
async def transcribe_audio(
    file: UploadFile = File(...),
    language: str = Form("th"),
    model: Optional[str] = Form(None),
    prompt: Optional[str] = Form("ตัดคำภาษาไทย เว้นวรรคตามหลักภาษาอย่างเป็นธรรมชาติ ซับไตเติลภาษาไทย"),
):
    if ENGINE == "none":
        raise HTTPException(
            status_code=500,
            detail="No supported Whisper engine found. Please install mlx-whisper (Mac) or faster-whisper (Windows).",
        )

    # Save uploaded file to temp directory
    suffix = Path(file.filename or "audio.mp3").suffix or ".mp3"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp_file:
        tmp_path = tmp_file.name
        content = await file.read()
        tmp_file.write(content)

    try:
        selected_model = model or ("mlx-community/whisper-large-v3" if ENGINE == "mlx-whisper" else "large-v3")
        print(f"[SUBTHAITLE] Transcribing audio with engine: {ENGINE}, model: {selected_model}, lang: {language}...")

        if ENGINE == "mlx-whisper":
            raw_result = transcribe_with_mlx(
                tmp_path,
                model_name=selected_model,
                language=language,
                initial_prompt=prompt,
            )
            # Format mlx_whisper result into standard schema
            segments_out = []
            words_out = []
            full_text = raw_result.get("text", "").strip()

            for idx, seg in enumerate(raw_result.get("segments") or []):
                seg_words = []
                for w in seg.get("words") or []:
                    w_text = (w.get("text") or w.get("word") or "").strip()
                    if w_text:
                        w_item = WordItem(
                            word=w_text,
                            start=round(float(w.get("start", 0)), 3),
                            end=round(float(w.get("end", 0)), 3),
                            confidence=round(float(w.get("probability", 1.0)), 2) if "probability" in w else 1.0,
                        )
                        seg_words.append(w_item)
                        words_out.append(w_item)

                segments_out.append(
                    SegmentItem(
                        id=idx,
                        start=round(float(seg.get("start", 0)), 3),
                        end=round(float(seg.get("end", 0)), 3),
                        text=seg.get("text", "").strip(),
                    )
                )

            return TranscribeResponse(
                success=True,
                text=full_text,
                segments=segments_out,
                words=words_out,
                engine=ENGINE,
                model=selected_model,
            )

        elif ENGINE == "faster-whisper":
            raw_result = transcribe_with_faster_whisper(
                tmp_path,
                model_name=selected_model,
                language=language,
                initial_prompt=prompt,
            )
            return TranscribeResponse(
                success=True,
                text=raw_result.get("text", ""),
                segments=[SegmentItem(**s) for s in raw_result.get("segments", [])],
                words=[WordItem(**w) for w in raw_result.get("words", [])],
                duration=raw_result.get("duration"),
                engine=ENGINE,
                model=selected_model,
            )

    except Exception as e:
        print(f"[SUBTHAITLE] Transcription error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Local Transcription Failed: {str(e)}")
    finally:
        # Clean up temporary audio file
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8765))
    print(f"\n=======================================================")
    print(f"  🚀 SUBTHAITLE Local Whisper Server running on:")
    print(f"  👉 http://localhost:{port}")
    print(f"  👉 Engine: {ENGINE} (Platform: {PLATFORM_SYSTEM} {platform.machine()})")
    print(f"=======================================================\n")
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="info")
